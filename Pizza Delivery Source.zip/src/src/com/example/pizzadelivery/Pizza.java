package com.example.pizzadelivery;

public class Pizza extends ItemPedido {
	
	public Pizza(int id, int tamanho)
	{
		this.Id = id;
		this.Tipo = 0;
		this.Tamanho = tamanho;
		this.Quantidade = 0;
	}
	
}
