package com.example.pizzadelivery;

public class Bebida extends ItemPedido {

	public Bebida(int id)
	{
		this.Id = id;
		this.Tipo = 1;
		this.Tamanho = 0;
		this.Quantidade = 0;
	}
	
}
