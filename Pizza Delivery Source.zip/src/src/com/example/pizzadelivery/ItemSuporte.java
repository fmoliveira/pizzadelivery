package com.example.pizzadelivery;

import android.widget.TextView;

public class ItemSuporte {

	public TextView txtQuantidade;
	public TextView txtItemPedido;
	public TextView txtSubtotal;
	
}
